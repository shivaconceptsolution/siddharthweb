package controllers;

import model.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SiController {
	
	@RequestMapping("Siload")
	public ModelAndView Si(@ModelAttribute("Siddharthweb") Si s,ModelMap model)
	{
		float si=0;
		if (s!=null)
		{
			si=(s.getP()*s.getR()*s.getT())/100;
			
		}
		model.addAttribute("key", si);
		return new ModelAndView("siview","command",new Si());
	}

}
