package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import model.Prime;
@Controller
public class PrimeController {
   
	@RequestMapping("prime")
	public ModelAndView Prime(@ModelAttribute("Siddharthweb")Prime s, ModelMap model)
	{
		String st = "";
		int i;
		if(s!=null)
		{
			for(i=2;i<s.getNum();i++)
			{
				if(s.getNum()%i==0)
				{
					st = "Not prime";
					break;
				}
			}
			if(s.getNum() == i)
			{
				st = "Prime";
			}
			model.addAttribute("key",st);
		}
		return new ModelAndView("prime","command",new Prime());
	}
}
